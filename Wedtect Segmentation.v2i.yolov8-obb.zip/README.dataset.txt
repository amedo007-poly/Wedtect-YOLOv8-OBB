# Wedtect Segmentation > 2025-09-24 2:31am
https://universe.roboflow.com/segmentation-gly4x/wedtect-segmentation

Provided by a Roboflow user
License: CC BY 4.0

